# FR24 ground-truth harvest — REQUIRED protocol (CSV + KML)

> A batched run on 2026-06-11 spent the whole daily FR24 export quota (25) but
> saved only 1 file: each download was aborted when the browser navigated to the
> next flight, and FR24 meters the *export*, not the save. To make that
> impossible, harvesting MUST go through the controller below, which verifies
> every file on disk before advancing and caps the cost of any bug to ONE flight.

## What we collect
Every flight is harvested as a **CSV + KML pair**, both from FlightRadar24's
own per-flight export buttons (Gold login required).

## The one rule
**Never have more than one flight's exports outstanding, and never advance until
the files are confirmed saved.** Do NOT use `browser_batch` to fire multiple
navigate/download pairs. One flight at a time.

## Where the files come from (native export — confirmed 2026-06-17)
On `https://www.flightradar24.com/data/aircraft/<tail>` each flight row has a
**CSV** button and a **KML** button. Clicking each one:
- fires `https://www.flightradar24.com/download/check-quota` (this is the meter), and
- downloads `<FLIGHTID>.csv` / `<FLIGHTID>.kml` to `~/Downloads`.

The CSV is byte-for-byte FR24 (`Timestamp,UTC,Callsign,Position,Altitude,Speed,Direction`).
The KML is FR24's rich native format (info-card, airport/photo metadata, per-segment
placemarks) — it CANNOT be reconstructed from `flight-playback.json`; it must come
from the KML button.

**CSV and KML are metered separately → a CSV+KML flight costs 2 export units.**
So the daily ceiling of 25 = **12 flights/batch (24 units) with the 25th unit held
back as a one-unit error reserve.**

Older flights aren't on the initial page (it loads the most recent ~100). Click
**"Load earlier flights"** until the target date appears — this is enumeration and
costs **no quota**. (Helicopters here are active; expect a handful of clicks to
reach July 2025, near the 365-day Gold floor.)

## Low-credit batch path (PREFERRED since 2026-06-26)
The one-at-a-time agent loop below is safe but expensive: ~5+ model tool calls
per flight, screenshots, DOM re-probing. The batch path keeps the model out of
the per-flight loop — the page does the clicking, the controller does the
filing — so a full day is ~5 calls and no screenshots.

```
python3 scripts/fr24_harvest.py status                 # sanity
python3 scripts/fr24_harvest.py plan --count 12        # JSON: targets grouped by tail (honors 2-unit budget)
# For EACH tail in the plan (one aircraft page at a time):
#   - browser: navigate to /data/aircraft/<tail>  (sign in as Gold)
#   - inject scripts/fr24_batch_click.js ONCE, then in the SAME call:
#         await fr24Batch([<that tail's flight_ids>], {paceMs:1500})
#     It pages back with "Load earlier flights" until the rows exist, then
#     clicks each flight's CSV+KML. Files land in ~/Downloads as <flightid>.csv/.kml.
#   - DO NOT navigate away until commit-batch has run (navigation aborts downloads).
python3 scripts/fr24_harvest.py commit-batch           # finalize EVERYTHING on disk (no quota cost)
python3 scripts/fr24_harvest.py reconcile              # set used_today = saved*2 (true spend)
```
`commit-batch` is idempotent and resumable: re-run it and already-saved flights
skip, present+valid files get filed, missing/stub downloads are reported and
left queued. It costs no quota (fetching already happened in the browser).

Known DOM hooks (no need to re-discover):
- export buttons: `button[data-filetype="csv"|"kml"][data-flight="<flightid>"]`
- pager button:   `#btn-load-earlier-flights`
- each row carries `data-timestamp` (Unix s) and an `a.btn-playback` whose href holds the flight id.

Notes:
- Downloads fire from a plain `button.click()` (confirmed 2026-06-25) — no real
  cursor needed, so no screenshots. Pace clicks ~1.5 s so FR24/Chrome keep up.
- CSV is the source of truth for "harvested"; KML is best-effort (a valid CSV is
  filed even if its KML is a stub). A flight still costs 2 units (both metered).
- `plan`/`next`/`commit`/`commit-batch` all take `--no-kml` (1 unit, CSV only).
- To cut credits further, run this scheduled task with a minimal plugin set and
  on a cheaper model — it is mechanical.

## The loop (every run)
```
python3 scripts/fr24_harvest.py status          # quota used/remaining, budget, queue
loop:
  python3 scripts/fr24_harvest.py next           # prints exactly ONE target (or STOPs)
      # exit 3 = no full flight affordable (<2 units left) -> STOP
      # exit 4 = queue empty -> STOP
  <browser> on /data/aircraft/<tail>, find the flight's row, click CSV then KML.
            Two files land in ~/Downloads: <FLIGHTID>.csv and <FLIGHTID>.kml.
  python3 scripts/fr24_harvest.py commit TAIL DATE FLIGHTID
      # finds BOTH downloads (native <flightid>.* names accepted), validates both,
      # files them as ground_truth/<TAIL>/<TAIL>_<DATE>_<FLIGHTID>.csv/.kml,
      # counts 2 units.
      # exit 0 = pair verified+saved+counted -> advance
      # exit 2 = a download missing/empty/stub -> STOP THIS RUN NOW
  if commit exited non-zero: STOP. Do not fetch anything else.
```
CSV-only fallback (1 unit, no KML required): add `--no-kml` to both `next` and `commit`.

For a known no-coverage tail/date (CSV button returns an empty track):
`python3 scripts/fr24_harvest.py miss TAIL DATE FLIGHTID nocoverage`

## Why this is safe
- `commit` only succeeds if BOTH files are really on disk and valid (CSV: canonical
  header + >=3 points; KML: >=500 B, has `<Placemark>` + coordinates). **Both-or-neither**:
  if either is bad, nothing is filed and the flight stays queued for a clean retry.
- The ledger (`_harvest_ledger.json`) counts **2 units per CSV+KML flight** and
  **hard-stops at 25**; `next` refuses once fewer than 2 units remain, so a clean
  batch is 12 flights and never spends the reserve.
- **Empty/stub file = quota exhaustion** -> ledger marked `exhausted`, run stops.
  A merely *missing* download stops the run too (exit 2) but stays **resumable**
  (not marked exhausted; the flight remains in the queue).
- Idempotent: an already-saved flight (CSV present) short-circuits in `commit` and
  is skipped by `next`, so crashes/re-runs never double-spend a saved flight.
- Bad files are quarantined to `ground_truth/_quarantine/`.

## Priority order
The carryover queue is sorted oldest-first (oldest flights age out of Gold's rolling
365-day floor first). Known watchlist tails with NO FR24 coverage (skip):
N411H, C6062, C6054, C6038.

## Token / enumeration (legacy, no quota cost)
The native buttons use the page's own session token, so no token handling is needed
for harvesting. For bulk enumeration only, the API is:
`flight/list.json?query=<reg>&fetchBy=reg&page=1&limit=100&timestamp=<unix>&token=<token>`
(`&olderThenFlightId=<id>` pages back; `data:null` => no coverage).

## Note on KML backfill
Flights harvested before 2026-06-17 are CSV-only (KMLs were added starting that day).
Adding KMLs to old flights is a separate opt-in backfill, not part of the daily loop.
