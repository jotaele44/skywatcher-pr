# Ground-truth harvest reconciliation — 2026-06-11

Audit of all harvest logs/state vs files actually on disk, plus a coverage check of the watchlist, to confirm nothing was overlooked.

## Today's harvest (verified)
- **25 FR24 tracks saved today**, 7,958 track points, all schema-valid, 0 filename/track-date mismatches.
- Covers the full **2025-06-11 → 2025-06-23** at-risk window (soonest to age out of FR24 Gold's rolling 365-day floor):
  06-11 ×7 · 06-12 ×2 · 06-13 ×1 · 06-14 ×1 · 06-16 ×3 · 06-17 ×2 · 06-18 ×4 · 06-19 ×2 · 06-22 ×2 · 06-23 ×1
- Tails: N413LP, N999ZY, N5854Z.

## Logs revised in this pass
- `todays_batch.csv` — was stale (24/25 `QUOTA_LOST_RETRY`); now all 25 = `HARVESTED` with point counts.
- `_harvest_carryover_2026-06-12.csv` — dropped 24 now-harvested; **then merged 110 newly-found flights → 160 pending** (oldest-first).
- `_harvest_log_2026-06-11.csv` — consolidated per-flight record of today's 25 saves.
- `_harvest_ledger.json` — note corrected: limit is a rolling burst throttle (~25 rapid reqs, ~30-min recovery), not a hard daily cap.

## RESOLVED this pass

### Coverage gap on previously-unchecked watchlist tails — FOUND & QUEUED
7 watchlist tails had never been enumerated for the Jun–Jul window. Read-only enumeration (no quota cost) found they all have FR24 coverage and **~110 in-window flights, essentially none harvested**:

| Tail | New in-window | Notes |
|---|---|---|
| N150F | 44 | very active (07-03 ×10, 07-09 ×11) |
| N13VL | 28 | earliest 06-14 |
| N407PR | 14 | sensitive (promoted from hold) |
| N767PD | 11 | PR Police FURA |
| N684JB | 8 | earliest 06-13 |
| N429LE | 4 | |
| N999DM | 1 | |

All 110 added to the carryover queue (now 160 pending, span 2025-06-13 → 2025-07-31). Earliest (06-13/06-14/06-18) age out within 2–7 days — next priority after tonight.

## OPEN FINDINGS (still unresolved)

### 1. Index sync gap — BIGGEST item
**118 harvested CSVs are on disk but absent from `summary.csv` and the sqlite `track_points` index** the pipeline reads:
- N5854Z 98/98 · N413LP 12/12 · N999ZY 8/8 un-indexed (N196DM 45 ✓ indexed).
- Today's 25 = 0/25 ingested.
Consequence: today's harvest + a large prior-session backlog is invisible to `flight_analyzer`/`mission_inference` until an ingester computes derived metrics (points, track_km, path_shape, has_hover/loop/orbit, alt/speed max) into `summary.csv` + `track_points`. No safe one-command ingester for FR24 CSVs exists in the main tree. **Recommend: build/run one before relying on the index.**

### 2. Archive-import tails not FR24-cross-checked (4)
`N79036, N26370, N90JF, N888EV` are already in the index from operator ADS-B archive uploads (N79036 = Jun 2025; others Dec25–Jan26). FR24 re-enumeration deferred as largely redundant; a cross-check could confirm the archive isn't missing June dates (lower priority).

### 3. Data-quality / housekeeping
- `N5854Z_2025-06-12_3ac46baa.csv` is a **6-point stub** (short ground/taxi segment) — real but minimal; flag for the analyzer.
- Confirmed **no-coverage** (do-not-requeue) still valid, no contradictions: N5854Z 2025-06-15, 07-06, 07-31, 09-18, 10-04.
- Harmless duplicate copies of today's CSVs remain in `~/Downloads` (different mount; controller copies rather than moves).

## Recommended next actions
1. **Build + run a ground-truth ingester** to fold the 118 (+future) CSVs into `summary.csv`/sqlite. *(highest value — without it the pipeline can't see the harvest)*
2. Work the **160-flight pending queue** oldest-first via the safe controller; next at-risk are 06-13/06-14/06-18 (N684JB, N13VL).
3. Optional: FR24 cross-check of the 4 archive tails.
